import React from 'react';
import { ShoppingCart, User, Copy, Check, Sparkles } from 'lucide-react';
import type { Message } from '../types';

interface MessageBubbleProps {
  message: Message;
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Failed to copy text:', error);
    }
  };

  const formatContent = (content: string) => {
    return content
      .split('\n')
      .map((line, index) => {
        // Handle bold text with **
        line = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        
        // Handle bullet points
        if (line.trim().startsWith('•') || line.trim().startsWith('-')) {
          return (
            <div key={index} className="ml-4 mb-1 flex items-start gap-2">
              <span className="text-emerald-400 mt-1">•</span>
              <span dangerouslySetInnerHTML={{ __html: line.trim().substring(1).trim() }} />
            </div>
          );
        }
        
        // Handle numbered lists
        if (/^\d+\./.test(line.trim())) {
          return (
            <div key={index} className="ml-4 mb-1">
              <span dangerouslySetInnerHTML={{ __html: line.trim() }} />
            </div>
          );
        }
        
        // Handle headers (lines that end with :)
        if (line.trim().endsWith(':') && line.trim().length < 50) {
          return (
            <div key={index} className="font-semibold mt-3 mb-1 text-emerald-400 flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              <span dangerouslySetInnerHTML={{ __html: line.trim() }} />
            </div>
          );
        }
        
        // Handle special creator response styling
        if (line.includes('🌟') && line.includes('Reshu Kushwah')) {
          return (
            <div key={index} className="text-center py-3 px-4 bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-lg border border-purple-500/30 mb-3 backdrop-blur-sm">
              <span className="text-lg font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent" dangerouslySetInnerHTML={{ __html: line.trim() }} />
            </div>
          );
        }
        
        // Regular paragraphs
        if (line.trim()) {
          return (
            <div key={index} className="mb-2">
              <span dangerouslySetInnerHTML={{ __html: line.trim() }} />
            </div>
          );
        }
        return <div key={index} className="h-2" />;
      });
  };

  if (message.isTyping) {
    return (
      <div className="flex items-start gap-3 mb-6">
        <div className="flex-shrink-0 w-8 h-8 bg-gradient-to-br from-emerald-500 to-cyan-500 rounded-full flex items-center justify-center">
          <ShoppingCart className="w-4 h-4 text-white" />
        </div>
        <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl rounded-tl-md px-4 py-3 max-w-3xl border border-gray-700/50">
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
            <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
            <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`flex items-start gap-3 mb-6 ${message.isUser ? 'flex-row-reverse' : ''}`}>
      <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
        message.isUser 
          ? 'bg-gradient-to-br from-purple-500 to-pink-500' 
          : 'bg-gradient-to-br from-emerald-500 to-cyan-500'
      }`}>
        {message.isUser ? (
          <User className="w-4 h-4 text-white" />
        ) : (
          <ShoppingCart className="w-4 h-4 text-white" />
        )}
      </div>
      
      <div className={`group relative max-w-3xl ${
        message.isUser 
          ? 'bg-gradient-to-br from-purple-600 to-pink-600 text-white rounded-2xl rounded-tr-md border border-purple-500/50' 
          : 'bg-gray-800/70 backdrop-blur-sm text-gray-100 rounded-2xl rounded-tl-md border border-gray-700/50'
      } px-4 py-3 hover:shadow-lg hover:shadow-purple-500/20 transition-all duration-200`}>
        <div className="prose prose-sm max-w-none">
          {message.isUser ? (
            <div>{message.content}</div>
          ) : (
            <div className="space-y-1">
              {formatContent(message.content)}
            </div>
          )}
        </div>
        
        {!message.isUser && (
          <button
            onClick={handleCopy}
            className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-all duration-200 p-1.5 hover:bg-gray-700/50 rounded-lg"
            title="Copy message"
          >
            {copied ? (
              <Check className="w-4 h-4 text-emerald-400" />
            ) : (
              <Copy className="w-4 h-4 text-gray-400" />
            )}
          </button>
        )}
      </div>
    </div>
  );
};