import React from 'react';
import { ShoppingCart, Settings, Sparkles, Zap } from 'lucide-react';

interface HeaderProps {
  onOpenSettings: () => void;
  isApiConfigured: boolean;
}

export const Header: React.FC<HeaderProps> = ({ onOpenSettings, isApiConfigured }) => {
  return (
    <header className="bg-gray-900/80 backdrop-blur-xl border-b border-purple-500/30 px-6 py-4 relative">
      <div className="absolute inset-0 bg-gradient-to-r from-purple-600/10 to-pink-600/10"></div>
      <div className="max-w-4xl mx-auto flex items-center justify-between relative z-10">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-to-br from-emerald-500 to-cyan-500 rounded-xl shadow-lg">
            <ShoppingCart className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white flex items-center gap-2">
              <span className="bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
                Grocery Generator AI
              </span>
              <Sparkles className="w-5 h-5 text-yellow-400 animate-pulse" />
            </h1>
            <p className="text-sm text-gray-300 flex items-center gap-2">
              <Zap className="w-4 h-4 text-purple-400" />
              Powered by Gemini 2.0 • {isApiConfigured ? (
                <span className="text-emerald-400 font-medium">Ready to help!</span>
              ) : (
                <span className="text-red-400 font-medium">Configuration needed</span>
              )}
            </p>
          </div>
        </div>
        
        <button
          onClick={onOpenSettings}
          className={`p-2 rounded-lg transition-all hover:scale-105 backdrop-blur-sm ${
            isApiConfigured 
              ? 'bg-gray-800/50 text-gray-300 hover:bg-gray-700/50 border border-gray-600/50' 
              : 'bg-red-500/20 text-red-400 hover:bg-red-500/30 animate-pulse border border-red-500/50'
          }`}
          title="API Settings"
        >
          <Settings className="w-5 h-5" />
        </button>
      </div>
    </header>
  );
};