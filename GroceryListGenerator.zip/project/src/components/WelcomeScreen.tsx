import React from 'react';
import { ShoppingCart, Zap, Shield, Globe, Sparkles, Heart, ChefHat, Apple } from 'lucide-react';

interface WelcomeScreenProps {
  onExampleClick: (example: string) => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onExampleClick }) => {
  const examples = [
    "Create a weekly grocery list for a family of 4",
    "Suggest healthy breakfast recipes",
    "Plan meals for weight loss",
    "What groceries do I need for Italian pasta?",
    "Budget-friendly grocery shopping tips",
    "Vegetarian meal prep ideas",
    "Who made you?",
    "Generate a shopping list for Indian cuisine"
  ];

  const features = [
    {
      icon: ShoppingCart,
      title: "Smart Grocery Lists",
      description: "Generate personalized shopping lists based on your needs and preferences",
      gradient: "from-emerald-500 to-teal-500"
    },
    {
      icon: ChefHat,
      title: "Meal Planning",
      description: "Get customized meal plans with recipes and ingredient calculations",
      gradient: "from-purple-500 to-pink-500"
    },
    {
      icon: Apple,
      title: "Nutrition Focused",
      description: "Receive healthy food suggestions and nutritional guidance",
      gradient: "from-orange-500 to-red-500"
    },
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Instant responses powered by Google's latest Gemini 2.0 model",
      gradient: "from-blue-500 to-cyan-500"
    }
  ];

  return (
    <div className="flex-1 flex items-center justify-center p-6">
      <div className="max-w-4xl w-full text-center">
        <div className="mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <h2 className="text-4xl font-bold bg-gradient-to-r from-emerald-400 via-cyan-400 to-purple-400 bg-clip-text text-transparent">
              Welcome to Grocery Generator AI
            </h2>
            <Sparkles className="w-8 h-8 text-yellow-400 animate-pulse" />
          </div>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Your intelligent shopping companion powered by Gemini 2.0! I help you plan meals, 
            create grocery lists, find recipes, and make smart food choices.
          </p>
          <div className="mt-4 flex items-center justify-center gap-2 text-sm text-gray-400">
            <span>Created with</span>
            <Heart className="w-4 h-4 text-red-400 animate-pulse" />
            <span>by <strong className="text-emerald-400">Reshu Kushwah</strong></span>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {features.map((feature, index) => (
            <div key={index} className="bg-gray-800/50 backdrop-blur-xl p-6 rounded-xl border border-gray-700/50 hover:border-purple-500/50 hover:shadow-2xl hover:shadow-purple-500/20 transition-all duration-300 transform hover:-translate-y-2 group">
              <div className={`w-12 h-12 bg-gradient-to-br ${feature.gradient} rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}>
                <feature.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold text-white mb-2 group-hover:text-emerald-400 transition-colors">{feature.title}</h3>
              <p className="text-sm text-gray-400 group-hover:text-gray-300 transition-colors">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="mb-8">
          <h3 className="text-xl font-semibold text-white mb-6 flex items-center justify-center gap-2">
            <Sparkles className="w-5 h-5 text-emerald-400" />
            <span className="bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
              Try these examples:
            </span>
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
            {examples.map((example, index) => (
              <button
                key={index}
                onClick={() => onExampleClick(example)}
                className="p-4 text-left bg-gray-800/30 backdrop-blur-sm hover:bg-gradient-to-r hover:from-purple-600/20 hover:to-pink-600/20 border border-gray-700/50 hover:border-purple-500/50 rounded-lg transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/20 group transform hover:-translate-y-1"
              >
                <span className="text-gray-300 group-hover:text-white transition-colors">
                  "{example}"
                </span>
              </button>
            ))}
          </div>
        </div>

        <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 backdrop-blur-sm border border-purple-500/30 rounded-xl p-6">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Sparkles className="w-5 h-5 text-emerald-400" />
            <p className="text-emerald-400 font-semibold">Pro tip:</p>
          </div>
          <p className="text-gray-300">
            I'm your smart grocery assistant! Ask me about meal planning, shopping lists, recipes, 
            nutrition advice, or anything food-related. Don't worry about perfect spelling - 
            I understand what you need! Try asking "Who made you?" to learn about my creator! 🌟
          </p>
        </div>
      </div>
    </div>
  );
};