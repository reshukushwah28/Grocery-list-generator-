import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { MessageBubble } from './components/MessageBubble';
import { ChatInput } from './components/ChatInput';
import { ApiKeyModal } from './components/ApiKeyModal';
import { WelcomeScreen } from './components/WelcomeScreen';
import { geminiService } from './services/geminiService';
import type { Message } from './types';

function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isApiModalOpen, setIsApiModalOpen] = useState(false);
  const [apiKey, setApiKey] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Load API key from localStorage
    const savedApiKey = localStorage.getItem('gemini_api_key');
    if (savedApiKey) {
      setApiKey(savedApiKey);
      geminiService.initialize(savedApiKey);
    } else {
      setIsApiModalOpen(true);
    }
  }, []);

  useEffect(() => {
    // Auto-scroll to bottom when new messages are added
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSaveApiKey = (newApiKey: string) => {
    setApiKey(newApiKey);
    localStorage.setItem('gemini_api_key', newApiKey);
    
    const success = geminiService.initialize(newApiKey);
    if (!success) {
      alert('Failed to initialize Gemini API. Please check your API key.');
      return;
    }
  };

  const handleSendMessage = async (content: string) => {
    if (!geminiService.isInitialized()) {
      setIsApiModalOpen(true);
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      content,
      isUser: true,
      timestamp: new Date()
    };

    const typingMessage: Message = {
      id: 'typing',
      content: '',
      isUser: false,
      timestamp: new Date(),
      isTyping: true
    };

    setMessages(prev => [...prev, userMessage, typingMessage]);
    setIsLoading(true);

    try {
      const response = await geminiService.generateResponse(content);
      
      setMessages(prev => {
        const withoutTyping = prev.filter(msg => msg.id !== 'typing');
        
        if (response.error) {
          const errorMessage: Message = {
            id: (Date.now() + 1).toString(),
            content: `❌ ${response.error}`,
            isUser: false,
            timestamp: new Date()
          };
          return [...withoutTyping, errorMessage];
        }

        const aiMessage: Message = {
          id: (Date.now() + 1).toString(),
          content: response.text,
          isUser: false,
          timestamp: new Date()
        };
        
        return [...withoutTyping, aiMessage];
      });
    } catch (error) {
      setMessages(prev => {
        const withoutTyping = prev.filter(msg => msg.id !== 'typing');
        const errorMessage: Message = {
          id: (Date.now() + 1).toString(),
          content: '❌ An unexpected error occurred. Please try again.',
          isUser: false,
          timestamp: new Date()
        };
        return [...withoutTyping, errorMessage];
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleExampleClick = (example: string) => {
    handleSendMessage(example);
  };

  const isApiConfigured = geminiService.isInitialized();

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex flex-col relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-pink-500/20 to-purple-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-cyan-500/20 to-blue-500/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-br from-emerald-500/10 to-teal-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '4s' }}></div>
      </div>

      {/* Floating particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-gradient-to-r from-pink-400 to-purple-400 rounded-full opacity-30 animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 10}s`,
              animationDuration: `${10 + Math.random() * 20}s`
            }}
          />
        ))}
      </div>

      <Header 
        onOpenSettings={() => setIsApiModalOpen(true)}
        isApiConfigured={isApiConfigured}
      />
      
      <div className="flex-1 flex flex-col max-w-4xl mx-auto w-full relative z-10">
        {messages.length === 0 ? (
          <WelcomeScreen onExampleClick={handleExampleClick} />
        ) : (
          <div className="flex-1 overflow-y-auto p-6">
            {messages.map((message) => (
              <MessageBubble key={message.id} message={message} />
            ))}
            <div ref={messagesEndRef} />
          </div>
        )}
        
        <div className="p-6 pt-0">
          <ChatInput
            onSendMessage={handleSendMessage}
            disabled={!isApiConfigured || isLoading}
            placeholder={
              !isApiConfigured 
                ? "Please configure your Gemini API key first..."
                : isLoading 
                ? "AI is thinking..."
                : "Ask me about groceries, meal planning, recipes, or anything else!"
            }
          />
        </div>
      </div>

      <ApiKeyModal
        isOpen={isApiModalOpen}
        onClose={() => setIsApiModalOpen(false)}
        onSave={handleSaveApiKey}
        currentApiKey={apiKey}
      />
    </div>
  );
}

export default App;