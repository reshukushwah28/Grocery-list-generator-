export interface Message {
  id: string;
  content: string;
  isUser: boolean;
  timestamp: Date;
  isTyping?: boolean;
}

export interface ApiKeyConfig {
  geminiApiKey: string;
}

export interface ChatResponse {
  text: string;
  error?: string;
}