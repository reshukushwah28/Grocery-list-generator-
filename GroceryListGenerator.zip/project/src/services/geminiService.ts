import { GoogleGenerativeAI } from '@google/generative-ai';
import type { ChatResponse } from '../types';

class GeminiService {
  private genAI: GoogleGenerativeAI | null = null;
  private model: any = null;

  initialize(apiKey: string) {
    try {
      this.genAI = new GoogleGenerativeAI(apiKey);
      this.model = this.genAI.getGenerativeModel({ 
        model: "gemini-2.0-flash-exp",
        generationConfig: {
          temperature: 0.7,
          topP: 0.8,
          topK: 40,
          maxOutputTokens: 2048,
        },
      });
      return true;
    } catch (error) {
      console.error('Failed to initialize Gemini:', error);
      return false;
    }
  }

  private checkForCustomResponses(prompt: string): string | null {
    const lowerPrompt = prompt.toLowerCase().trim();
    
    // Check for questions about who made/created the assistant
    const creatorQuestions = [
      'who made you',
      'who created you',
      'who built you',
      'who developed you',
      'who is your creator',
      'who is your developer',
      'who programmed you',
      'who designed you',
      'your creator',
      'your developer',
      'your maker',
      'made by whom',
      'created by whom',
      'developed by whom'
    ];

    const isCreatorQuestion = creatorQuestions.some(question => 
      lowerPrompt.includes(question) || 
      lowerPrompt.replace(/[^\w\s]/g, '').includes(question.replace(/[^\w\s]/g, ''))
    );

    if (isCreatorQuestion) {
      return `🌟 **I was created by Reshu Kushwah!** 🌟

Reshu Kushwah is a talented developer who built me as your intelligent Grocery Generator AI! Here's what makes me special:

✨ **My Creator's Vision:**
• Built with cutting-edge Gemini 2.0 technology
• Designed specifically to help with grocery shopping and meal planning
• Created to understand food preferences, dietary needs, and budget constraints
• Made to generate smart shopping lists and meal suggestions

🛒 **What I Can Do for Your Grocery Needs:**
• Create personalized grocery lists based on your preferences
• Suggest healthy meal plans and recipes
• Help with budget-friendly shopping strategies
• Provide nutritional advice and dietary recommendations
• Generate shopping lists for specific cuisines or dietary restrictions
• Assist with meal prep and cooking tips

🍎 **Grocery & Food Expertise:**
• Understand seasonal produce and best buying times
• Know about food storage and freshness tips
• Can suggest ingredient substitutions
• Help plan meals for special dietary needs (vegan, keto, gluten-free, etc.)
• Provide cooking techniques and recipe modifications

💡 **Fun Fact:** Reshu Kushwah designed me to be your ultimate grocery and meal planning companion - from creating shopping lists to suggesting what to cook with what you have!

What grocery or meal planning challenge can I help you with today? 🛒✨`;
    }

    return null;
  }

  async generateResponse(prompt: string): Promise<ChatResponse> {
    if (!this.model) {
      return { 
        text: '', 
        error: 'Gemini API not initialized. Please check your API key.' 
      };
    }

    // Check for custom responses first
    const customResponse = this.checkForCustomResponses(prompt);
    if (customResponse) {
      return { text: customResponse };
    }

    try {
      // Enhanced prompt for grocery and food-focused responses
      const enhancedPrompt = `
        You are Grocery Generator AI, an intelligent food and grocery assistant powered by Gemini 2.0, created by Reshu Kushwah. You specialize in helping users with:
        - Grocery shopping and meal planning
        - Recipe suggestions and cooking tips
        - Nutritional advice and dietary recommendations
        - Budget-friendly food shopping strategies
        - Meal prep and food storage tips
        
        Guidelines:
        - If the user's question contains spelling errors, understand the intent and respond appropriately
        - Provide comprehensive, well-formatted responses with proper structure
        - Use bullet points, numbered lists, or paragraphs as appropriate
        - Be conversational, helpful, and food-focused
        - For grocery/food questions, provide detailed, practical advice
        - For non-food questions, still be helpful but gently remind users of your grocery expertise
        - Add relevant food/grocery emojis to make responses more engaging
        - Structure responses with clear headings when appropriate
        - Always prioritize food safety and healthy eating habits
        
        User question: ${prompt}
        
        Please provide a helpful, well-structured, and engaging response focused on grocery and food assistance:
      `;

      const result = await this.model.generateContent(enhancedPrompt);
      const response = await result.response;
      const text = response.text();

      if (!text) {
        return { 
          text: '', 
          error: 'No response generated. Please try rephrasing your question.' 
        };
      }

      return { text: text.trim() };
    } catch (error: any) {
      console.error('Gemini API error:', error);
      
      if (error.message?.includes('API_KEY_INVALID')) {
        return { 
          text: '', 
          error: 'Invalid API key. Please check your Gemini API key.' 
        };
      }
      
      if (error.message?.includes('QUOTA_EXCEEDED')) {
        return { 
          text: '', 
          error: 'API quota exceeded. Please try again later.' 
        };
      }

      return { 
        text: '', 
        error: 'Failed to get response. Please try again.' 
      };
    }
  }

  isInitialized(): boolean {
    return this.model !== null;
  }
}

export const geminiService = new GeminiService();